//-----------------------------------------------------------------------
// Sequential LU Decomposition - C++ Sequential Version
//-----------------------------------------------------------------------
// Modified Lab Code for the Sequential Algorithm
// ----------------------------------------------------------------------
#include <iostream>
#include <iomanip>
#include <cmath>
#include <stdio.h>
#include <stdlib.h>   
using namespace std;
//-----------------------------------------------------------------------
//   Get user input of matrix dimension and printing option
//-----------------------------------------------------------------------
bool GetUserInput(int argc, char *argv[],int& n,int& isPrint)
{
	bool isOK = true;
	
	if(argc < 2) 
	{
			cout << "Arguments:<X> [<Y>]" << endl;
			cout << "X : Matrix size [X x X]" << endl;
			cout << "Y = 1: print the input/output matrix if X < 10" << endl;
			cout << "Y <> 1 or missing: does not print the input/output matrix" << endl;
		isOK = false;
	}
	else 
	{
		//get matrix size
		n = atoi(argv[1]);
		if (n <=0) 
		{
			isOK = false;
		}
		//is print the input/output matrix
		if (argc >=3)
			isPrint = (atoi(argv[2])==1 && n <=9)?1:0;
		else
			isPrint = 0;
	}
	return isOK;
}
//-----------------------------------------------------------------------
//Initialize the value of matrix a[n x n]
//-----------------------------------------------------------------------
void InitializeMatrix(float** &a,int n)
{
	a = new float*[n]; 
	a[0] = new float[n*n];
	for (int i = 1; i < n; i++)	a[i] = a[i-1] + n;

	for (int j = 0 ; j < n ; j++)
	{	
		for (int i = 0 ; i < n ; i++)
		{
            if (i == j) 
              a[j][i] = (((float)i+1)*((float)i+1))/(float)2;	
            else
              a[j][i] = (((float)i+1)+((float)j+1))/(float)2;
		}
	}
}
void InitializeMatrixL(float** &L,int n){
	L = new float*[n];
	L[0] = new float[n*n];
	for (int i = 1; i < n; i++)	L[i] = L[i-1] + n;

	for (int j = 0 ; j < n ; j++)
	{	
		for (int i = 0 ; i < n ; i++)
		{
            if (i == j) 
              L[j][i] = 1;	
            else
              L[j][i] = 0;
		}
	}	
}

//------------------------------------------------------------------
//delete matrix matrix a[n x n]
//------------------------------------------------------------------
void DeleteMatrix(float **a,int n)
{
	delete[] a[0];
	delete[] a; 
}
//------------------------------------------------------------------
//Print matrix	
//------------------------------------------------------------------
void PrintMatrix(float **a, int n) 
{
	for (int i = 0 ; i < n ; i++)
	{
		cout<< "Row " << (i+1) << ":\t" ;
		for (int j = 0 ; j < n ; j++)
		{
			printf("%.2f\t", a[j][i]);
		}
		cout<<endl ;
	}
}
void PrintMatrixU(float **a, int n) 
{
	for (int i = 0 ; i < n ; i++)
	{
		cout<< "Row " << (i+1) << ":\t" ;
		for (int j = 0 ; j < n ; j++)
		{
			if(j<i){
				a[j][i]=0;
			}
			printf("%.2f\t", a[j][i]);
		}
		cout<<endl ;
	}
}
//------------------------------------------------------------------
//Compute the Gaussian Elimination for matrix a[n x n]
//------------------------------------------------------------------
bool ComputeGaussianElimination(float **a, float **L, int n)
{
	float pivot,max,temp;
	int indmax,i,j,k,lk,master;
	float *tmp = new float[n];

	//Perform rowwise elimination
	for (k = 0 ; k < n-1 ; k++)
	{
		max = 0.0;
		indmax = k;

		//Find the pivot row
		for (i = k ; i < n ; i++) 
		{	
			temp = abs(a[k][i]);        
			if (temp > max) 
			{
				 max = temp;
				 indmax = i;
			}
		}

		//If matrix is singular set the flag & quit
		//if (max == 0) return false;

        // Swap rows if necessary
	    if (indmax != k)
		{
			for (j = k; j < n; j++) 
			{	
				temp = a[j][indmax];
				a[j][indmax] = a[j][k];
				a[j][k] = temp;
			}
		}
		pivot = -1.0/a[k][k];
		//Master 

		for (i = k+1 ; i < n ; i++)
		{
			tmp[i]= pivot*a[k][i];
			L[k][i]=((-1.0)*tmp[i]);
			for(j=k; j<n; j++){
				//cout << "process " << myProcessID << " writing tmp["<<i<<"]="<<tmp[i]<<" to L["<<k<<"]["<<i<<"]\n";
				a[j][i] = a[j][i] + tmp[i]*a[j][k];		
			}	
		}
		if (indmax != k){
			if(k==0){				
				//cout << "swapping " << indmax << " with " << k<<endl;
				temp=L[k][indmax];
				//cout << temp << ":"<<L[k][k+1]<<endl;
				L[k][indmax]=L[k][k+1];
				L[k][k+1]=temp;
			}
		}
	}

	delete[] tmp; 
	return true;
}
//------------------------------------------------------------------
// Main Program
//------------------------------------------------------------------
int main(int argc, char *argv[])
{
	float	**a;	
	float 	**L;
	int	n,isPrintMatrix;
	bool missing;	
	double runtime;

	
	//Master process get program input
	if (GetUserInput(argc, argv,n,isPrintMatrix)==false)
	{
		return 1;
	}


	//Initialize the value of matrix A[N][N]
	InitializeMatrix(a,n);
	InitializeMatrixL(L,n);

	//Prints the input maxtrix if needed
	if (isPrintMatrix==1)
	{
		cout<< "Input matrix:" << endl;
		PrintMatrix(a,n); 
		//cout<< "L initialized to:" << endl;
		//PrintMatrix(L,n);
	}
	runtime = clock()/(double)CLOCKS_PER_SEC;
	//Compute the Gaussian Elimination for matrix a[n x n]
	missing = ComputeGaussianElimination(a,L,n);


	runtime = (clock()/(double)CLOCKS_PER_SEC ) - runtime;

	//Print result matrix
	if (isPrintMatrix==1)
	{
		cout<< "Upper matrix:" << endl;
		PrintMatrixU(a,n); 
		cout << "Lower matrix:" << endl;
		PrintMatrix(L,n);
	}
	cout<< "LU Decomposition runs in "	<< setiosflags(ios::fixed) 
											<< setprecision(2)  
											<< runtime << " seconds \n";
 	


	//All process delete matrix
	DeleteMatrix(a,n);	

	return 0;
}

